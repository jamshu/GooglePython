import urllib
url=sys.argv[1]
fp = urllib.urlopen(url)
text=fp.read()
return text 
